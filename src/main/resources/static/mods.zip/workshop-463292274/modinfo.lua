name = "全图"
description = "地图全开,配合更多图标显示更好"
author = "QQ3157747"
version = "0.3"

forumthread = ""

api_version = 10

icon_atlas = "modicon.xml"
icon = "modicon.tex"

all_clients_require_mod = true
client_only_mod = false
dst_compatible = true