﻿使用中文mod首先在网盘下载中文补丁覆盖游戏 http://pan.baidu.com/s/1o6l6fAq
之后所有中文mod才可以正常显示中文.并且支持中文输入
更多中文mod 
http://steamcommunity.com/sharedfiles/filedetails/?id=460972875