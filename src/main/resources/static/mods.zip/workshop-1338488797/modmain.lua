
-- Import the engine.
modimport("engine.lua")

-- Imports to keep the keyhandler from working while typing in chat.
Load "chatinputscreen"
Load "consolescreen"
Load "textedit"

PrefabFiles = {
	"kuro",
	"kuro_none", 
	"skullcane", "shadowapple", 
}
Assets = {
    
	
	Asset( "IMAGE", "images/saveslot_portraits/kuro.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/kuro.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/kuro.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/kuro.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/kuro_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/kuro_silho.xml" ),

    Asset( "IMAGE", "bigportraits/kuro.tex" ),
    Asset( "ATLAS", "bigportraits/kuro.xml" ),
	
	Asset( "IMAGE", "images/map_icons/kuro.tex" ),
	Asset( "ATLAS", "images/map_icons/kuro.xml" ),

	Asset( "IMAGE", "images/avatars/avatar_kuro.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_kuro.xml" ),
	Asset( "IMAGE", "images/avatars/avatar_ghost_kuro.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_kuro.xml" ),
Asset( "IMAGE", "images/avatars/self_inspect_kuro.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_kuro.xml" ),
Asset( "IMAGE", "images/names_kuro.tex" ),
    Asset( "ATLAS", "images/names_kuro.xml" ),
	
    Asset( "IMAGE", "bigportraits/kuro_none.tex" ),
    Asset( "ATLAS", "bigportraits/kuro_none.xml" ),
	Asset("ANIM", "anim/shadowapple.zip"),
	Asset("ATLAS", "images/inventoryimages/shadowapple.xml"),
	Asset("IMAGE", "images/inventoryimages/shadowapple.tex"),
	Asset( "ATLAS", "images/hud/vampiretab.xml" ),
	Asset("SOUNDPACKAGE", "sound/reaper.fev"),
    Asset("SOUND", "sound/reaper.fsb"),
	
	
}


RemapSoundEvent( "dontstarve/characters/reaper/death_voice", "reaper/characters/reaper/death_voice" )
RemapSoundEvent( "dontstarve/characters/reaper/hurt", "reaper/characters/reaper/hurt" )
RemapSoundEvent( "dontstarve/characters/reaper/talk_LP", "reaper/characters/reaper/talk_LP" )



local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS
local FOODTYPE = GLOBAL.FOODTYPE
local FOODGROUP = GLOBAL.FOODGROUP
GLOBAL.FOODTYPE.NIGHTMARE = "NIGHTMARE"
GLOBAL.TUNING.KURO = {}
GLOBAL.TUNING.KURO.KEYTWO = GetModConfigData("key2") or 122





	local function HunSoul(inst)
    inst:AddComponent("edible")
    inst.components.edible.foodtype = GLOBAL.FOODTYPE.NIGHTMARE
    inst.components.edible.healthvalue = 10
    inst.components.edible.sanityvalue = 15
    inst.components.edible.hungervalue = 5
end
AddPrefabPostInit("nightmarefuel", HunSoul)

local function SecondFn(inst)
if inst:HasTag("playerghost") then return end
if inst.transformed then
inst.AnimState:SetBuild("kuro")
	
	
	SpawnPrefab("shadow_bishop_fx").Transform:SetPosition(inst:GetPosition():Get())
	SpawnPrefab("shadow_despawn").Transform:SetPosition(inst:GetPosition():Get())
inst.components.locomotor.walkspeed = (TUNING.WILSON_WALK_SPEED)
inst.components.locomotor.runspeed = (TUNING.WILSON_RUN_SPEED)
inst.components.sanity.neg_aura_mult = 0.3
inst.components.health.absorb = 0
inst.components.hunger.hungerrate = 1 * TUNING.WILSON_HUNGER_RATE


	
	

 
else
inst.AnimState:SetBuild("demonkuro")
SpawnPrefab("shadow_bishop_fx").Transform:SetPosition(inst:GetPosition():Get())
	SpawnPrefab("shadow_shield3").Transform:SetPosition(inst:GetPosition():Get())
	
	
	inst.components.sanity:DoDelta(-15)
	
	inst.components.sanity.neg_aura_mult = 0
	
inst.components.locomotor.walkspeed = 6
inst.components.locomotor.runspeed = 7.25
inst.components.health.absorb = 0.25

inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * 2.5)

 
end
 
inst.transformed = not inst.transformed
 
-- inst.components.health:SetCurrentHealth(1)
-- inst.components.health:DoDelta(0)
return true
 
end
 
AddModRPCHandler("kuro", "SECOND", SecondFn)

local TECH = GLOBAL.TECH
local vampiretab = AddRecipeTab("Kuro", 998, "images/hud/vampiretab.xml", "vampiretab.tex", "vampirekuro")

local skullcane_recipe = AddRecipe("skullcane", 
{  Ingredient("boneshard", 2), Ingredient("cane", 1), Ingredient("reviver", 1)}, 
vampiretab, 
TECH.NONE, 
nil, 
nil, 
nil, 
nil, 
nil, 
"images/inventoryimages/skullcane.xml",
"skullcane.tex") 



local shadowapple_recipe = AddRecipe("shadowapple", { Ingredient("berries", 3), Ingredient("nightmarefuel", 1) },
 vampiretab, TECH.NONE, nil, nil, nil, nil, "vampirekuro", 
"images/inventoryimages/shadowapple.xml")

GLOBAL.STRINGS.NAMES.SKULLCANE = "Skull Cane"
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.SKULLCANE = "It's look powerful!"
STRINGS.RECIPE_DESC.SKULLCANE = "A cane with dark magic"





GLOBAL.STRINGS.NAMES.SHADOWAPPLE = "Shadow Apple"
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.SHADOWAPPLE = "Smell's good. But look so dangerous!"
STRINGS.RECIPE_DESC.SHADOWAPPLE = "An apple from Hell"

-- The character select screen lines
STRINGS.CHARACTER_TITLES.kuro = "The Dark Prince"
STRINGS.CHARACTER_NAMES.kuro = "Kuro"
STRINGS.CHARACTER_DESCRIPTIONS.kuro = "*Half Vampire\n*Half Demon\n*Master of Hell"




STRINGS.CHARACTER_QUOTES.kuro = "\"Charlie? She's....ahaha \""

-- Custom speech strings
STRINGS.CHARACTERS.KURO = require "speech_kuro"

-- The character's name as appears in-game 
STRINGS.NAMES.kuro = "Kuro"

AddMinimapAtlas("images/map_icons/kuro.xml")

-- Add mod character to mod character list. Also specify a gender. Possible genders are MALE, FEMALE, ROBOT, NEUTRAL, and PLURAL.
AddModCharacter("kuro", "MALE")

