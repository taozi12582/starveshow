local assets=
{
    Asset("ANIM", "anim/skullcane.zip"),
    Asset("ANIM", "anim/swap_skullcane.zip"),
  
    Asset("ATLAS", "images/inventoryimages/skullcane.xml"),
    Asset("IMAGE", "images/inventoryimages/skullcane.tex"),
}

local prefabs = 
{
	
}

local HPABSORB = 0.35


local function onattack(inst, attacker)
	  local attacker = inst.components.inventoryitem.owner
      if math.random() < HPABSORB then
	  		attacker.components.health:DoDelta(5)
			SpawnPrefab("sanity_lower").Transform:SetPosition(inst:GetPosition():Get())
		end
end




local function OnEquip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_skullcane", "swap_skullcane")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")

end

 

local function OnUnequip(inst, owner)

    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")




end

local function fn()
  
    local inst = CreateEntity()
 
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
    
    MakeInventoryPhysics(inst)   
      
    inst.AnimState:SetBank("skullcane")
    inst.AnimState:SetBuild("skullcane")
    inst.AnimState:PlayAnimation("idle")
 
    inst:AddTag("sharp")



 
    if not TheWorld.ismastersim then
        return inst
    end
 
    inst.entity:SetPristine()
     
    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(TUNING.AXE_DAMAGE)
	  inst.components.weapon:SetOnAttack(onattack)
    inst:AddComponent("inspectable")
      
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.keepondeath = true
    inst.components.inventoryitem.imagename = "skullcane"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/skullcane.xml"
      


    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip( OnEquip )
    inst.components.equippable:SetOnUnequip( OnUnequip )
 inst.components.equippable.walkspeedmult = TUNING.CANE_SPEED_MULT
	inst.components.inventoryitem.keepondeath = true
	     
    return inst
end



return  Prefab("common/inventory/skullcane", fn, assets, prefabs) 