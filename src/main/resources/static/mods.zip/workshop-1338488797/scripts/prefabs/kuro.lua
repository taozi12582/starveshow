
local MakePlayerCharacter = require "prefabs/player_common"


local assets = {
    Asset("SCRIPT", "scripts/prefabs/player_common.lua"),

Asset("ANIM", "anim/demonkuro.zip"),


}
local prefabs = {}

-- Custom starting items
local start_inv = {
	"nightmarefuel","nightmarefuel","nightmarefuel",
}   

																																	local DEVILEYES = {
	day = "images/colour_cubes/day05_cc.tex",
	dusk = "images/colour_cubes/dusk03_cc.tex",
	night = "images/colour_cubes/ruins_dim_cc.tex",
	full_moon = "images/colour_cubes/purple_moon_cc.tex",
}


-- When the character is revived from human
local function onbecamehuman(inst)
	-- Set speed when reviving from ghost (optional)
	inst.components.locomotor:SetExternalSpeedMultiplier(inst, "kuro_speed_mod", 1.25)
end

local function onbecameghost(inst)
	-- Remove speed modifier when becoming a ghost
   inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "kuro_speed_mod")
end

-- When loading or spawning the character
local function onload(inst)
    inst:ListenForEvent("ms_respawnedfromghost", onbecamehuman)
    inst:ListenForEvent("ms_becameghost", onbecameghost)

    if inst:HasTag("playerghost") then
        onbecameghost(inst)
    else
        onbecamehuman(inst)
    end
end

local function vampire_heal(inst, data)
    local victim = data.victim
    if not inst.components.health:IsDead() and not victim:HasTag("fish") then
        local total_health = victim.components.health:GetMaxWithPenalty()
local fx1 = SpawnPrefab("shadow_puff_large_front")
			fx1.Transform:SetPosition(inst.Transform:GetWorldPosition());fx1.Transform:SetScale(1.3,1.3,1.3)

        																							inst.components.health:DoDelta(total_health * .05) 
    end
end

local function vampire(inst)
	if TheWorld.state.phase == "day"  then
	 inst.components.combat.damagemultiplier = 1
	 elseif TheWorld.state.phase == "dusk" and inst.transformed then

		 inst.components.combat.damagemultiplier = 1.75
		 elseif TheWorld.state.phase == "night" and inst.transformed then

	 inst.components.combat.damagemultiplier = 2.5
	
	elseif TheWorld.state.phase == "dusk" and not inst.transformed then
	 inst.components.combat.damagemultiplier = 1.25
	elseif TheWorld.state.phase == "night" and not inst.transformed then
	 inst.components.combat.damagemultiplier = 1.5
	

		
		
		
	
		
		
		

	
	

		end
end

local function sanityfn(inst)
	local delta = 0
	
	if TheWorld.state.isday then
		delta = -0.25
		elseif TheWorld.state.isdusk then
inst.components.sanity.night_drain_mult = 0

elseif TheWorld.state.isnight then
delta = 0.3
	end
	return delta
end

  																						local smallScale = 1
																							local medScale = 1.3
																															local largeScale = 1.6
																									local superScale = 2.8

local function spawnspirit(inst, x, y, z, scale)
    local fx = SpawnPrefab("disease_puff")
    fx.Transform:SetPosition(x, y, z)
    fx.Transform:SetScale(scale, scale, scale)
end


local function IsValidVictim(victim)
    return victim ~= nil
         and not ((victim:HasTag("prey") and victim:HasTag("hostile")) or
                victim:HasTag("veggie") or
                victim:HasTag("structure") or
                victim:HasTag("wall") or
                victim:HasTag("companion"))
        and victim.components.health ~= nil
        and victim.components.combat ~= nil
end

local function onkilled(inst, data)
    local victim = data.victim
    if IsValidVictim(victim) then
        
      
     

       
            local time = victim.components.health.destroytime or 2
            local x, y, z = victim.Transform:GetWorldPosition()
            local scale = (victim:HasTag("smallcreature") and smallScale)
                        or (victim:HasTag("largecreature") and largeScale)
			or (victim:HasTag("epic") and superScale)
                        or medScale
            inst:DoTaskInTime(time, spawnspirit, x, y, z, scale)
			
       
    end
end



local function UpdateNightVision(inst, phase)
	local enable = phase == "night"
	inst:DoTaskInTime(enable and 0 or 1, function(inst)
		inst.components.playervision:ForceNightVision(enable)
		inst.components.playervision:SetCustomCCTable(enable and DEVILEYES or nil)
	end)
end

local function OnInitNightVision(inst)
	if TheWorld.ismastersim or inst.HUD then
		inst:WatchWorldState("phase", UpdateNightVision)
		UpdateNightVision(inst, TheWorld.state.phase)
	end
end

local function CanEatNightmares(inst)
	
		if inst.components.eater.preferseating then
			table.insert(inst.components.eater.preferseating, FOODTYPE.NIGHTMARE)
			table.insert(inst.components.eater.caneat, FOODTYPE.NIGHTMARE)
			inst:AddTag(FOODTYPE.NIGHTMARE.."_eater")
		else
			table.insert(inst.components.eater.foodprefs, "NIGHTMARE")
			inst:AddTag(FOODTYPE.NIGHTMARE.."_eater")
		end
	end


																					local function oneat(inst, food)  --triggers appearence change and/or hallucinations on eating nightmare fuel
       
	if food and food.components.edible and food.components.edible.foodtype == "NIGHTMARE" then
			
			
			SpawnPrefab("sanity_raise").Transform:SetPosition(inst:GetPosition():Get())
			inst.components.talker:Say("Umm....My soul")
			elseif food.prefab == "margarita" then
			inst.components.sanity:DoDelta(15)
			inst.components.talker:Say("Ummm.....A Deadly Apple...So good!")
		   
		   
			
			
	end
end


-- This initializes for both the server and client. Tags can be added here.
local common_postinit = function(inst) 
	-- Minimap icon
	inst.MiniMapEntity:SetIcon( "kuro.tex" )
inst:DoTaskInTime(0, OnInitNightVision)
inst.transformed = false 
inst:AddTag("bat")
inst:AddTag("vampirekuro")
	inst:AddComponent("keyhandler")
    inst.components.keyhandler:AddActionListener("kuro", TUNING.KURO.KEYTWO, "SECOND")

	

end


-- This initializes for the server only. Components are added here.
local master_postinit = function(inst)
	-- choose which sounds this character will play
	inst.soundsname = "reaper"
	
	-- Uncomment if "wathgrithr"(Wigfrid) or "webber" voice is used
    --inst.talker_path_override = "dontstarve_DLC001/characters/"
	
	-- Stats	
	inst.components.health:SetMaxHealth(150)
	inst.components.hunger:SetMax(150)
	inst.components.sanity:SetMax(150)
inst.components.sanity.neg_aura_mult = 0.3
	inst.components.locomotor.walkspeed = (TUNING.WILSON_WALK_SPEED)
inst.components.locomotor.runspeed = (TUNING.WILSON_RUN_SPEED)
	inst.components.health.absorb = 0
	inst.components.eater:SetOnEatFn(oneat)
	
	-- Hunger rate (optional)
	inst.components.hunger.hungerrate = 1 * TUNING.WILSON_HUNGER_RATE
	
	local refreshTime = 1/5
	inst:DoPeriodicTask(refreshTime, function() vampire(inst, refreshTime) end)
inst.components.sanity.custom_rate_fn = sanityfn
inst:ListenForEvent("killed", vampire_heal)
inst:ListenForEvent("killed", onkilled)
CanEatNightmares(inst)
	inst.OnLoad = onload
    inst.OnNewSpawn = onload
	
end

return MakePlayerCharacter("kuro", prefabs, assets, common_postinit, master_postinit, start_inv)
