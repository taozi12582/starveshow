local Assets =
{
	
	Asset("IMAGE", "images/inventoryimages/shadowapple.tex"),
    Asset("ATLAS", "images/inventoryimages/shadowapple.xml"),
Asset("ANIM", "anim/shadowapple.zip"),
}

local function doareasleep(inst, range, time)
    local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, range, nil, { "playerghost", "FX", "DECOR", "INLIMBO" }, { "sleeper", "player" })
    local canpvp = not inst:HasTag("player") or TheNet:GetPVPEnabled()
    for i, v in ipairs(ents) do
        if (v == inst or canpvp or not v:HasTag("player")) and
            not (v.components.freezable ~= nil and v.components.freezable:IsFrozen()) and
            not (v.components.pinnable ~= nil and v.components.pinnable:IsStuck()) then
            local mount = v.components.rider ~= nil and v.components.rider:GetMount() or nil
            if mount ~= nil then
                mount:PushEvent("ridersleep", { sleepiness = 7, sleeptime = time + math.random() })
            end
            if v:HasTag("player") then
                v:PushEvent("yawn", { grogginess = 4, knockoutduration = time + math.random() })
            elseif v.components.sleeper ~= nil then
                v.components.sleeper:AddSleepiness(7, time + math.random())
            elseif v.components.grogginess ~= nil then
                v.components.grogginess:AddGrogginess(4, time + math.random())
            else
                v:PushEvent("knockedout")
            end
        end
    end
end

local function oneaten(inst, eater)
if eater.prefab == "kuro" then

   inst.components.lootdropper:SpawnLootPrefab("nightmarefuel")
   inst.components.lootdropper:SpawnLootPrefab("nightmarefuel")
   inst.components.lootdropper:SpawnLootPrefab("nightmarefuel")
   
 SpawnPrefab("shadow_despawn").Transform:SetPosition(inst:GetPosition():Get())
 
else
    eater.SoundEmitter:PlaySound("dontstarve/charlie/warn")
	
	 inst.components.lootdropper:SpawnLootPrefab("nightmarefuel")
   inst.components.lootdropper:SpawnLootPrefab("nightmarefuel")
   
	 for i, v in ipairs(AllPlayers) do
		v:ShakeCamera(CAMERASHAKE.FULL, .7, .02, .3, inst, 40)
	end
	SpawnPrefab("shadow_despawn").Transform:SetPosition(inst:GetPosition():Get())
	
    eater:DoTaskInTime(0.5, function() 
        doareasleep(eater, TUNING.MANDRAKE_SLEEP_RANGE, 5)
    end)
	end
end

local function fn(Sim)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()

	MakeInventoryPhysics(inst)
	MakeSmallBurnable(inst)
	MakeSmallPropagator(inst)
	
	inst.AnimState:SetBank("shadowapple")
	inst.AnimState:SetBuild("shadowapple")
	inst.AnimState:PlayAnimation("idle", false)
	
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddTag("preparedfood")

	inst:AddComponent("edible")
	inst.components.edible.healthvalue = 50
	inst.components.edible.hungervalue = 30
	inst.components.edible.sanityvalue = (-5)
	inst.components.edible:SetOnEatenFn(oneaten)
	inst.components.edible.foodtype = "VEGGIE"

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/shadowapple.xml"

	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM

	inst:AddComponent("perishable")
	inst.components.perishable:SetPerishTime(TUNING.PERISH_SLOW)
	inst.components.perishable:StartPerishing()
	inst.components.perishable.onperishreplacement = "spoiled_food"

	inst:AddComponent("bait")
	
	inst:AddComponent("tradable")
	inst.components.tradable.goldvalue = 3
	inst.components.tradable.dubloonvalue = 2
	
	inst:AddComponent("lootdropper")
	
	
    
	
	return inst
end


return Prefab( "common/inventory/shadowapple", fn, Assets )