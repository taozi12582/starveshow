local assets =
{
	Asset( "ANIM", "anim/kuro.zip" ),
	Asset( "ANIM", "anim/ghost_kuro_build.zip" ),
}

local skins =
{
	normal_skin = "kuro",
	ghost_skin = "ghost_kuro_build",
}

local base_prefab = "kuro"

local tags = {"KURO", "CHARACTER"}

return CreatePrefabSkin("kuro_none",
{
	base_prefab = base_prefab, 
	skins = skins, 
	assets = assets,
	tags = tags,
	
	skip_item_gen = true,
	skip_giftable_gen = true,
})