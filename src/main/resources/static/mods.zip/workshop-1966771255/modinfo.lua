name = "Let me know where u are"
description = "Adds minimap icon for"
author = "Elice"
--original:DST where is my beefalo
version = "1.02"

forumthread = ""

api_version = 10

--compative for dlc
dst_compatible = true
dont_starve_compatible = true
reign_of_giants_compatible = true
shipwrecked_compatible = false
--which u need
all_clients_require_mod = false
client_only_mod = true
--select icon
icon_atlas = "modicon.xml"
icon = "modicon.tex"

--Making config list
configuration_options =
{
    {
		name = "beefalo","babybeefalo",
		label = "beefalos",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},	
	{
		name = "carrot_planted",
		label = "carrot",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "flint",
		label = "flint",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "rabbithole",
		label = "rabbithole",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "rocky",
		label = "rocky",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "lightninggoat",
		label = "Volt Goats",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "molehill",
		label = "moleworm",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "koalefant_winter","koalefant_summer",
		label = "koalefants",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "blue_mushroom","red_mushroom","green_mushroom",
		label = "mushrooms",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "mandrake","mandrake_active","mandrake_planted",
		label = "mandrake",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "hound","firehound","icehound",
		label = "hound",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "skeleton",
		label = "skeleton",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "fireflies",
		label = "fireflies",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "dirtpile",
		label = "dirtpile",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "animal_track",
		label = "animal track",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "tentacle",
		label = "tentacle",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "chester_eyebone",
		label = "chester_eyebone",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "pighead",
		label = "pighead",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "krampus",
		label = "krampus",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "minotaur",
		label = "minotaur",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "bat",
		label = "bat",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "spider_hider",
		label = "spider_hider",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "bishop","bishop_nightmare","knight","knight_nightmare","rook","rook_nightmare",
		label = "Clockworks",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "spider_dropper",
		label = "spider_dropper",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "worm",
		label = "worm",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "walrus",
		label = "walrus",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "tentacle_pillar",
		label = "tentacle_pillar",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "bunnyman",
		label = "bunnyman",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "leif",
		label = "leif",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "leif_sparse",
		label = "leif_sparse",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "spiderqueen",
		label = "spiderqueen",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "moose",
		label = "moose",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "mooseegg",
		label = "mooseegg",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "deerclops",
		label = "deerclops",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "bearger",
		label = "bearger",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "warg",
		label = "varg",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "sandbagsmall",
		label = "sandbagsmall",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "wall_hay",
		label = "wall_hay",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "wall_wood",
		label = "wall_wood",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "wall_stone",
		label = "wall_stone",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "wall_limestone",
		label = "wall_limestone",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "wall_ruins",
		label = "wall_ruins",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "sculpture_bishophead","sculpture_knighthead","sculpture_rooknose","swap_sculpture_bishophead","swap_sculpture_knighthead","swap_sculpture_rooknose",
		label = "Suspicious Marbles",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "deer",
		label = "no-eyed deer",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "fruitdragon",
		label = "saladmander",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "bernie_inactive","bernie_active",
		label = "bernie",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "malbatross",
		label = "malbatross",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	{
		name = "hutch_fishbowl",
		label = "star-sky",
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	--[[ for copy and paste
	{
		name = ,
		label = ,
		hover = "show icon or hide icon",
		options =	
		{
			{description = "Show", data = true},
			{description = "Hide", data = false},
		},
		default = true,
	},
	]]
	
	
	
	
	
	
}