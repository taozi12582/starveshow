--------------------------------------------------
--gloval settings
_G = GLOBAL
local require = _G.require
local unpack = _G.unpack
local FindEntity = _G.FindEntity
local Vector3 = _G.Vector3
if _G.TheNet:IsDedicated() or _G.TheNet:GetServerGameMode() == "lavaarena" then return end
--------------------------------------------------

-----------------------------------------------



--don't let disable icons when logged out
--[[not work find another
local MapRevealable = Class(function(self, inst)
    self.inst = inst

    self.refreshperiod = 1.5
    self.iconname = nil
    self.iconpriority = nil
    self.iconprefab = "globalmapicon"
    self.icon = nil
    self.task = nil
    self.revealsources = {}
    self._onremovesource = function(source)
        self:RemoveRevealSource(source)
    end

    self:Start(math.random() * self.refreshperiod)
end)

function MapRevealable:SetIcon(iconname)
    if self.iconname ~= iconname then
        self.iconname = iconname
        if self.icon ~= nil then
            self.icon.MiniMapEntity:SetIcon(iconname)
        end
    end
end

function MapRevealable:SetIconPriority(priority)
    if self.iconpriority ~= priority then
        self.iconpriority = priority
        if self.icon ~= nil then
            self.icon.MiniMapEntity:SetPriority(priority)
        end
    end
end

function MapRevealable:SetIconPrefab(prefab)
    if self.iconprefab ~= prefab then
        self.iconprefab = prefab
        if self.icon ~= nil then
            self:StopRevealing()
            self:RefreshRevealSources()
        end
    end
end

function MapRevealable:RefreshRevealSources()
    if next(self.revealsources) == nil then
        self:StopRevealing()
        return
    end
    local restriction
    for k, v in pairs(self.revealsources) do
        if v.restriction == nil then
            self:StartRevealing()
            return
        else
            restriction = v.restriction
        end
    end
    self:StartRevealing(restriction)
end

function MapRevealable:StartRevealing(restriction)
    if self.icon == nil then
        self.icon = SpawnPrefab(self.iconprefab)
        if self.iconpriority ~= nil then
            self.icon.MiniMapEntity:SetPriority(self.iconpriority)
        end
        self.icon:TrackEntity(self.inst, restriction, self.iconname)
    else
        self.icon.MiniMapEntity:SetRestriction(restriction or "")
    end
end

function MapRevealable:StopRevealing()
    if self.icon ~= nil then
        self.icon:Remove()
        self.icon = nil
    end
end

function MapRevealable:Refresh()
    if self.task ~= nil then
        if GetClosestInstWithTag("maprevealer", self.inst, 30) ~= nil then
            self:AddRevealSource("maprevealer")
        else
            self:RemoveRevealSource("maprevealer")
        end
    end
end

local function Refresh(inst, self)
    self:Refresh()
end

function MapRevealable:Start(delay)
    if self.task == nil then
        self.task = self.inst:DoPeriodicTask(self.refreshperiod, Refresh, delay, self)
    end
end

function MapRevealable:Stop()
    self:RemoveRevealSource("maprevealer")
    if self.task ~= nil then
        self.task:Cancel()
        self.task = nil
    end
end

function MapRevealable:OnRemoveFromEntity()
    self:Stop()
    local toremove = {}
    for k, v in pairs(self.revealsources) do
        table.insert(toremove, k)
    end
    for i, v in ipairs(toremove) do
        self:RemoveRevealSource(v)
    end
end
]]
----------------------------------------------
--Run program about Addicons
Assets = {}

local  function AddIcons(prefabs)
        table.insert(Assets, Asset("IMAGE", "images/" .. prefabs .. ".tex"))
        table.insert(Assets, Asset("ATLAS", "images/" .. prefabs .. ".xml"))
		--[[not work for keep remind minimap
		table.insert(Assets, Asset("MINIMAPS", "images/" .. prefab .. ".tex"))
		table.insert(Assets, Asset("MINIMAPS", "images/" .. prefab .. ".xml"))
		]]
		AddMinimapAtlas("images/" .. prefabs .. ".xml")
        AddPrefabPostInit(prefabs, function(inst)
        inst.entity:AddMiniMapEntity()
        inst.MiniMapEntity:SetIcon(prefabs .. ".tex")
        end)
        
end



-----------------------------------------
--Making List for Run Addicons
List = {}

if GetModConfigData("beefalo")~=false then
        table.insert(List, "beefalo")
end
if GetModConfigData("babybeefalo")~=false then
        table.insert(List, "babybeefalo")
end
if GetModConfigData("carrot_planted")~=false then
        table.insert(List, "carrot_planted")
end
if GetModConfigData("flint")~=false then
        table.insert(List, "flint")
end
if GetModConfigData("rabbithole")~=false then
        table.insert(List, "rabbithole")
end
if GetModConfigData("rocky")~=false then
        table.insert(List, "rocky")
end
if GetModConfigData("lightninggoat")~=false then
        table.insert(List, "lightninggoat")
end
if GetModConfigData("molehill")~=false then
        table.insert(List, "molehill")
end
if GetModConfigData("koalefant_winter")~=false then
        table.insert(List, "koalefant_winter")
end
if GetModConfigData("koalefant_summer")~=false then
        table.insert(List, "koalefant_summer")
end
if GetModConfigData("blue_mushroom")~=false then
        table.insert(List, "blue_mushroom")
end
if GetModConfigData("red_mushroom")~=false then
        table.insert(List, "red_mushroom")
end
if GetModConfigData("green_mushroom")~=false then
        table.insert(List, "green_mushroom")
end
if GetModConfigData("mandrake")~=false then
        table.insert(List, "mandrake")
end
if GetModConfigData("mandrake_active")~=false then
        table.insert(List, "mandrake_active")
end
if GetModConfigData("mandrake_planted")~=false then
        table.insert(List, "mandrake_planted")
end
if GetModConfigData("hound")~=false then
        table.insert(List, "hound")
end
if GetModConfigData("firehound")~=false then
        table.insert(List, "firehound")
end
if GetModConfigData("icehound")~=false then
        table.insert(List, "icehound")
end
if GetModConfigData("skeleton")~=false then
        table.insert(List, "skeleton")
end
if GetModConfigData("fireflies")~=false then
        table.insert(List, "fireflies")
end
if GetModConfigData("dirtpile")~=false then
        table.insert(List, "dirtpile")
end
if GetModConfigData("animal_track")~=false then
        table.insert(List, "animal_track")
end
if GetModConfigData("tentacle")~=false then
        table.insert(List, "tentacle")
end
if GetModConfigData("chester_eyebone")~=false then
        table.insert(List, "chester_eyebone")
end
if GetModConfigData("pighead")~=false then
        table.insert(List, "pighead")
end
if GetModConfigData("krampus")~=false then
        table.insert(List, "krampus")
end
if GetModConfigData("minotaur")~=false then
        table.insert(List, "minotaur")
end
if GetModConfigData("bat")~=false then
        table.insert(List, "bat")
end
if GetModConfigData("spider_hider")~=false then
        table.insert(List, "spider_hider")
end
if GetModConfigData("bishop")~=false then
        table.insert(List, "bishop")
end
if GetModConfigData("bishop_nightmare")~=false then
        table.insert(List, "bishop_nightmare")
end
if GetModConfigData("knight")~=false then
        table.insert(List, "knight")
end
if GetModConfigData("knight_nightmare")~=false then
        table.insert(List, "knight_nightmare")
end
if GetModConfigData("rook")~=false then
        table.insert(List, "rook")
end
if GetModConfigData("rook_nightmare")~=false then
        table.insert(List, "rook_nightmare")
end
if GetModConfigData("spider_dropper")~=false then
        table.insert(List, "spider_dropper")
end
if GetModConfigData("worm")~=false then
        table.insert(List, "worm")
end
if GetModConfigData("walrus")~=false then
        table.insert(List, "walrus")
end
if GetModConfigData("tentacle_pillar")~=false then
        table.insert(List, "tentacle_pillar")
end
if GetModConfigData("bunnyman")~=false then
        table.insert(List, "bunnyman")
end
if GetModConfigData("leif")~=false then
        table.insert(List, "leif")
end
if GetModConfigData("leif_sparse")~=false then
        table.insert(List, "leif_sparse")
end
if GetModConfigData("spiderqueen")~=false then
        table.insert(List, "spiderqueen")
end
if GetModConfigData("moose")~=false then
        table.insert(List, "moose")
end
if GetModConfigData("mooseegg")~=false then
        table.insert(List, "mooseegg")
end
if GetModConfigData("deerclops")~=false then
        table.insert(List, "deerclops")
end
if GetModConfigData("bearger")~=false then
        table.insert(List, "bearger")
end
if GetModConfigData("warg")~=false then
        table.insert(List, "warg")
end
if GetModConfigData("sandbagsmall")~=false then
        table.insert(List, "sandbagsmall")
end
if GetModConfigData("wall_hay")~=false then
        table.insert(List, "wall_hay")
end
if GetModConfigData("wall_wood")~=false then
        table.insert(List, "wall_wood")
end
if GetModConfigData("wall_stone")~=false then
        table.insert(List, "wall_stone")
end
if GetModConfigData("wall_limestone")~=false then
        table.insert(List, "wall_limestone")
end
if GetModConfigData("wall_ruins")~=false then
        table.insert(List, "wall_ruins")
end
if GetModConfigData("sculpture_bishophead")~=false then
        table.insert(List, "sculpture_bishophead")
end
if GetModConfigData("sculpture_knighthead")~=false then
        table.insert(List, "sculpture_knighthead")
end
if GetModConfigData("sculpture_rooknose")~=false then
        table.insert(List, "sculpture_rooknose")
end
if GetModConfigData("swap_sculpture_bishophead")~=false then
        table.insert(List, "swap_sculpture_bishophead")
end
if GetModConfigData("swap_sculpture_knighthead")~=false then
        table.insert(List, "swap_sculpture_knighthead")
end
if GetModConfigData("swap_sculpture_rooknose")~=false then
        table.insert(List, "swap_sculpture_rooknose")
end
if GetModConfigData("deer")~=false then
        table.insert(List, "deer")
end
if GetModConfigData("fruitdragon")~=false then
        table.insert(List, "fruitdragon")
end
if GetModConfigData("bernie_inactive")~=false then
        table.insert(List, "bernie_inactive")
end
if GetModConfigData("bernie_active")~=false then
        table.insert(List, "bernie_active")
end
if GetModConfigData("malbatross")~=false then
        table.insert(List, "malbatross")
end
if GetModConfigData("hutch_fishbowl")~=false then
        table.insert(List, "hutch_fishbowl")
end
--[[ for copy and paste
if GetModConfigData()~=false then
        table.insert(List, )
end
]]
-------------------------------------------------------
--Run Addicons by List data
  for k,v in pairs(List) do
	 AddIcons(v) 
	 --[[MapRevealable:SetIcon(v)
	 MapRevealable:SetIconPriority(v)
	 MapRevealable:SetIconPrefab(v)]]
end