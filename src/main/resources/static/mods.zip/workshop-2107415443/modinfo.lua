-- This information tells other players more about the mod
name = "克尔苏加德"
description = "克尔苏加德 \n作为一名学者，他有很多书籍\n炼金术大师，可以合成齿轮\n巫妖不会冻僵\n怕热，夏天san之会持续缓慢降低"
author = "Wawin & Yuki清"
version = "3.0" -- This is the version of the template. Change it to your own number.

-- This is the URL name of the mod's thread on the forum; the part after the ? and before the first & in the url
forumthread = " "


-- This lets other players know if your mod is out of date, update it to match the current version in the game
api_version = 10

-- Compatible with Don't Starve Together
dst_compatible = true

-- Not compatible with Don't Starve
dont_starve_compatible = false
reign_of_giants_compatible = false

-- Character mods need this set to true
all_clients_require_mod = true 

icon_atlas = "modicon.xml"
icon = "modicon.tex"

-- The mod's tags displayed on the server list
server_filter_tags = {
"character",
}

configuration_options = {
	{
        name = "stafffreenum",
        label = "黑檀之寒法杖攻击冰冻概率",
        options =	{
						{description = "10%", data = 0.1},
						{description = "20%", data = 0.2},
						{description = "50%", data = 0.5},
						{description = "80%", data = 0.8},
						{description = "100%", data = 1},
					},
		default = 0.2,
    },

    {
		name = "staffdmg",
		label = "黑檀之寒法杖攻击力",
		options =
		{

			{description = "36", data = 36},
			{description = "50", data = 50},
			{description = "75(默认)", data = 75},
			{description = "84", data = 84},
			{description = "96", data = 96},
		},
		default = 75,
	},
--[[
    {
		name = "staffins",
		label = "黑檀之寒法杖耐久设置",
		options =
		{

			{description = "80", data = 80},
			{description = "150", data = 150},
			{description = "无耐久(默认)", data = 0},
			{description = "200", data = 200},
			{description = "300", data = 300},
		},
		default = 0,
	},
]]
} 

--configuration_options = {}