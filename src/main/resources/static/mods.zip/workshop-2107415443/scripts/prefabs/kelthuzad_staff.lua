local assets =
{
    Asset("ANIM", "anim/kelthuzad_staff.zip"),
    Asset("ANIM", "anim/swap_kelthuzad_staff.zip"),
    Asset("ANIM", "anim/floating_items.zip"),

    Asset("ANIM", "anim/lavaarena_heal_projectile.zip"),
    Asset("ANIM", "anim/yukistaff_projectile.zip"),

    Asset( "ATLAS", "images/inventoryimages/kelthuzad_staff.xml"),
	  Asset( "IMAGE", "images/inventoryimages/kelthuzad_staff.tex" )
}

local function onattack(inst, attacker, target)
     if target and target.components.freezable and math.random() <= TUNING.STAFFFREENUM then
              target.components.freezable:AddColdness(3, 3)                                     
     end
end  

local function onequip(inst, owner)
 if owner.prefab == "kelthuzad" then
      owner.AnimState:OverrideSymbol("swap_object", "swap_kelthuzad_staff", "swap_kelthuzad_staff")      
      owner.AnimState:Show("ARM_carry")
      owner.AnimState:Hide("ARM_normal")

  if not TheWorld.state.isday then
       if inst._light == nil or not inst._light:IsValid() then
          inst._light = SpawnPrefab("kelthuzad_staff_light") --生成光源
          inst._light.entity:SetParent(owner.entity)  --给光源设置父节点
       end
   end

  else
      owner:DoTaskInTime(0, function()
          local inventory = owner.components.inventory 
            if inventory then
             inventory:DropItem(inst)
         end
      end)    
   end 
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")

      if inst._light ~= nil then
        if inst._light:IsValid() then
            inst._light:Remove()    --把光源去掉
        end
        inst._light = nil
    end
end


local function OnIsNight(inst, isnight)
    if inst._light == nil or not inst._light:IsValid() then
        inst._light = SpawnPrefab("kelthuzad_staff_light") --生成光源
        inst._light.entity:SetParent(inst.entity)  --给光源设置父节点
    end
end    

local function OnIsDay(inst)    
    if inst._light ~= nil then
        if inst._light:IsValid() then
            inst._light:Remove()    --把光源去掉
        end
        inst._light = nil
    end
end

local function toground(inst)
    if TheWorld.state.isdusk or TheWorld.state.isnight then
       if inst._light == nil or not inst._light:IsValid() then
           inst._light = SpawnPrefab("kelthuzad_staff_light") --生成光源
            inst._light.entity:SetParent(inst.entity)  --给光源设置父节点
       end

     else
 
       if inst._light ~= nil then
          if inst._light:IsValid() then
              inst._light:Remove()    --把光源去掉
          end
          inst._light = nil

       end 
    end     
end

local function ShouldAcceptItem(inst, item)
    if item.prefab == "nightmarefuel" and inst.level < 3 then
        return true

    else
        return false
    end
end

local function OnGetItemFromPlayer(inst, giver, item)
        inst.experience = inst.experience + 1
        inst.components.named:SetName("黑檀之寒法杖\n当前经验值: "..inst.experience.."/"..(inst.level*10+10)) 
                if inst.experience >= (inst.level*10+10) then
                         inst.experience = inst.experience - (inst.level*10+10)
                         inst.level = inst.level + 1
                         inst.components.weapon:SetDamage(TUNING.STAFFFDMG+TUNING.STAFFFDMG*inst.level)
                         SpawnPrefab("shadow_despawn").Transform:SetPosition(inst.Transform:GetWorldPosition())
                         --inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/summon")
                     else
                     	   SpawnPrefab("pandorachest_reset").Transform:SetPosition(inst.Transform:GetWorldPosition())
                     	   inst.SoundEmitter:PlaySound("dontstarve/common/together/moonbase/repair", nil, 0.5)
            end       
end

local function onsave(inst, data)  --保存等级
    data.level = inst.level > 0 and inst.level or nil
    data.experience = inst.experience > 0 and inst.experience or nil
end  
    
local function onpreload(inst, data)
     if data then
         if data.level then
                inst.level = data.level
                inst.components.weapon:SetDamage(TUNING.STAFFFDMG+TUNING.STAFFFDMG*inst.level)
          end           
           
           if data.experience then
                  inst.experience = data.experience
                  inst.components.named:SetName("黑檀之寒法杖\n当前经验值: "..inst.experience.."/"..(inst.level*10+10)) 
          end     
     end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
    inst.entity:AddSoundEmitter()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("kelthuzad_staff")
    inst.AnimState:SetBuild("kelthuzad_staff")
    inst.AnimState:PlayAnimation("idle")

    inst.Transform:SetScale(1.2, 1.2, 1.2)

    inst:AddTag("sharp")
    inst:AddTag("pointy")

    --weapon (from weapon component) added to pristine state for optimization
    inst:AddTag("weapon")

    MakeInventoryFloatable(inst, "small", 0.2, 0.80)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.level = 0
    inst.experience = 0

    inst:AddComponent("weapon")
    inst.components.weapon:SetRange(10)
    inst.components.weapon:SetDamage(TUNING.STAFFFDMG)
    inst.components.weapon:SetOnAttack(onattack)
    inst.components.weapon:SetProjectile("yukistaff_projectile")

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "kelthuzad_staff"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/kelthuzad_staff.xml"

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
--[[
    if TUNING.STAFFFINS > 0 then
         inst:AddComponent("finiteuses")
         inst.components.finiteuses:SetMaxUses(TUNING.STAFFFINS)
         inst.components.finiteuses:SetUses(TUNING.STAFFFINS)
         inst.components.finiteuses:SetOnFinished(inst.Remove)
    end  
]]
    inst:AddComponent("trader")
    inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    inst.components.trader.onaccept = OnGetItemFromPlayer

    inst:WatchWorldState("isdusk", OnIsNight)
    inst:WatchWorldState("isday", OnIsDay)

    inst:ListenForEvent("ondropped", toground)

    inst:AddComponent("named")

    MakeHauntableLaunch(inst) 

    inst.OnSave = onsave
    inst.OnPreLoad = onpreload

    return inst
end

local function brusheslightfn()   --设置苔衣发卡的光源
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddLight()
    inst.entity:AddNetwork()

    inst:AddTag("FX")

    inst.Light:SetFalloff(0.55)  --衰减
    inst.Light:SetIntensity(.7) --亮度
    inst.Light:SetRadius(2)     --半径
    inst.Light:SetColour(140/255, 239/255, 255/255) --颜色，和灯泡花一样

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false

    return inst
end

local function pipethrown(inst)
    inst.AnimState:PlayAnimation("idle_loop", true)
end

local function onhit(inst, attacker, target)
    inst.AnimState:PlayAnimation("hit")
    inst:ListenForEvent("animover", inst.Remove)
end

local function yukistaff_projectilefn()   --设置苔衣发卡的光源
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
    MakeInventoryPhysics(inst)

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    inst:AddTag("projectile")

    inst.AnimState:SetBank("lavaarena_heal_projectile")
    inst.AnimState:SetBuild("yukistaff_projectile")
    inst.AnimState:PlayAnimation("idle_loop", true)
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")

    inst.AnimState:SetFinalOffset(-1)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(10)
    inst.components.projectile:SetOnHitFn(onhit)
    inst.components.projectile:SetOnMissFn(inst.Remove)
    --inst.components.projectile:SetOnThrownFn(pipethrown)

    return inst
end

return Prefab("kelthuzad_staff", fn, assets),
       Prefab("kelthuzad_staff_light", brusheslightfn),
       Prefab("yukistaff_projectile", yukistaff_projectilefn)