local assets =
{
	Asset( "ANIM", "anim/kelthuzad.zip" ),
	Asset( "ANIM", "anim/ghost_kelthuzad_build.zip" ),
}

local skins =
{
	normal_skin = "kelthuzad",
	ghost_skin = "ghost_kelthuzad_build",
}

local base_prefab = "kelthuzad"

local tags = {"BASE" ,"ESCTEMPLATE", "CHARACTER"}

return CreatePrefabSkin("kelthuzad_none",
{
	base_prefab = base_prefab, 
	skins = skins, 
	assets = assets,
	skin_tags = tags,
	
	build_name_override = "kelthuzad",
	rarity = "Character",
})