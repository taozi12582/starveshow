local MakePlayerCharacter = require "prefabs/player_common"

local assets = {         
         Asset( "ANIM", "anim/kelthuzad.zip" ),
         Asset( "ANIM", "anim/ghost_kelthuzad_build.zip" ),
         Asset("SCRIPT", "scripts/prefabs/player_common.lua"),
}

local prefabs = {

}

local start_inv = {}
--[[
for k, v in pairs(TUNING.GAMEMODE_STARTING_ITEMS) do
    start_inv[string.lower(k)] = v.KELTHUZAD
end
]]
local function sanityfn(inst)--, dt)
     if inst.components.temperature ~= nil and inst.components.temperature:IsOverheating() then
            return -1
     elseif TheWorld.state.issummer then
            return -0.05
     else
            return 0
     end       
end

local function equipscoutstuff(inst) 
    local scoutcap = SpawnPrefab("kelthuzad_staff")
    inst.components.inventory:Equip(scoutcap)              
end

-- This initializes for both the server and client. Tags can be added here.
local common_postinit = function(inst)
	  inst.MiniMapEntity:SetIcon( "kelthuzad.tex" )
	  inst:AddTag("kelthuzad")
      inst:AddTag("insomniac")
      inst:AddTag("bookbuilder")
      inst:AddTag("reader")

	  inst.soundsname = "wortox"
end

-- This initializes for the server only. Components are added here.
local master_postinit = function(inst)

    inst.OnNewSpawn = equipscoutstuff
   -- inst.starting_inventory = start_inv.default

    inst:AddComponent("reader")

    inst.Transform:SetScale(1.1, 1.1, 1.1)

	inst.components.health:SetMaxHealth(150)

	inst.components.sanity:SetMax(300)
    inst.components.sanity.custom_rate_fn = sanityfn --每秒都会执行的回san代码

    inst.components.hunger:SetMax(100)
    inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * 0.5)

    inst.components.locomotor.walkspeed = 4*1.5 
    inst.components.locomotor.runspeed = 6*1.5

    inst.components.temperature.mintemp = 5
    inst.components.health.fire_damage_scale = 2

    inst.components.builder.science_bonus = 1

    inst.components.talker.colour = Vector3(140/255, 239/255, 200/255, 1)
end

return MakePlayerCharacter("kelthuzad", prefabs, assets, common_postinit, master_postinit, start_inv)
