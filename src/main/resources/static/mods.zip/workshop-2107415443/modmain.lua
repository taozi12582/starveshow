PrefabFiles = {
	"kelthuzad",
	"kelthuzad_none",
   -- "nfx",
    "kelthuzad_staff"
}

Assets = {

    Asset("ANIM", "anim/kelthuzad.zip"),

    Asset( "IMAGE", "images/names_kelthuzad.tex" ),
    Asset( "ATLAS", "images/names_kelthuzad.xml" ),

    Asset( "IMAGE", "images/saveslot_portraits/kelthuzad.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/kelthuzad.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/kelthuzad.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/kelthuzad.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/kelthuzad_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/kelthuzad_silho.xml" ),

    Asset( "IMAGE", "bigportraits/kelthuzad.tex" ),
    Asset( "ATLAS", "bigportraits/kelthuzad.xml" ),

	Asset( "IMAGE", "images/map_icons/kelthuzad.tex" ),
	Asset( "ATLAS", "images/map_icons/kelthuzad.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_kelthuzad.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_kelthuzad.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_kelthuzad.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_kelthuzad.xml" ),
	
	Asset( "IMAGE", "images/avatars/self_inspect_kelthuzad.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_kelthuzad.xml" ),
	
	Asset( "IMAGE", "images/names_kelthuzad.tex" ),
    Asset( "ATLAS", "images/names_kelthuzad.xml" ),
	
    Asset( "IMAGE", "bigportraits/kelthuzad_none.tex" ),
    Asset( "ATLAS", "bigportraits/kelthuzad_none.xml" ),

    Asset( "ATLAS", "images/inventoryimages/kelthuzad_staff.xml"),
    Asset( "IMAGE", "images/inventoryimages/kelthuzad_staff.tex" ),

    Asset("ATLAS_BUILD", "images/inventoryimages/kelthuzad_staff.xml", 256)
}
--[[
RemapSoundEvent( "dontstarve/characters/tecolin/death_voice", "tecolin/characters/tecolin/death_voice" )
RemapSoundEvent( "dontstarve/characters/tecolin/hurt", "tecolin/characters/tecolin/hurt" )
RemapSoundEvent( "dontstarve/characters/tecolin/talk_LP", "tecolin/characters/tecolin/talk_LP" )
RemapSoundEvent( "dontstarve/characters/tecolin/emote", "tecolin/characters/tecolin/emote" )
RemapSoundEvent( "dontstarve/characters/tecolin/ghost_LP", "tecolin/characters/tecolin/ghost_LP" )
RemapSoundEvent( "dontstarve/characters/tecolin/yawn", "tecolin/characters/tecolin/yawn" )
RemapSoundEvent( "dontstarve/characters/tecolin/pose", "tecolin/characters/tecolin/pose" )
]]


local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS

local FOODTYPE = GLOBAL.FOODTYPE
local FOODGROUP = GLOBAL.FOODGROUP

GLOBAL.setmetatable(env,{__index=function(t,k) return GLOBAL.rawget(GLOBAL,k) end})

TUNING.STAFFFREENUM = GetModConfigData("stafffreenum")
TUNING.STAFFFDMG = GetModConfigData("staffdmg")
TUNING.KELTHUZAD_HEALTH = 150
TUNING.KELTHUZAD_HUNGER = 100
TUNING.KELTHUZAD_SANITY = 300
--TUNING.STAFFFINS = GetModConfigData("staffins")

TUNING.STARTING_ITEM_IMAGE_OVERRIDE.kelthuzad_staff = {atlas = "images/inventoryimages/kelthuzad_staff.xml", image = "kelthuzad_staff.tex"}

TUNING.GAMEMODE_STARTING_ITEMS.DEFAULT.KELTHUZAD = {"kelthuzad_staff"}          

PREFAB_SKINS["kelthuzad_none"] = {   --修复人物大图显示
	"kelthuzad_none",
}

STRINGS.SKIN_NAMES.kelthuzad_none = "克尔苏加德"  --检查界面显示的名字

STRINGS.CHARACTER_TITLES.kelthuzad = "克尔苏加德"
STRINGS.CHARACTER_NAMES.kelthuzad = "克尔苏加德"
STRINGS.CHARACTER_DESCRIPTIONS.kelthuzad = "*作为一名学者，他有很多书籍\n*炼金术大师，可以合成齿轮\n*巫妖不会冻僵\n*怕热，夏天san之会持续缓慢降低"

STRINGS.CHARACTER_QUOTES.kelthuzad = "远古之邪恶复生了！"
STRINGS.CHARACTER_SURVIVABILITY.kelthuzad = "不老不死, 永生不灭!"

STRINGS.CHARACTERS.GENERIC.DESCRIBE.kelthuzad = 
{
	GENERIC = "克尔苏加德!",
	ATTACKER = "即使是你, 也不该出手伤人!", --攻击过别人时
	MURDERER = "你让我感到害怕",  --杀害过别人时
	REVIVER = "Too cute to death~",  --拯救过别人时
	GHOST = "也许你已经习惯了死亡!",  --鬼魂状态时
}

-- The character's name as appears in-game 
STRINGS.NAMES.kelthuzad = "克尔苏加德"

STRINGS.RECIPE_DESC.GEARS  = "是时候进入新纪元了" 

AddMinimapAtlas("images/map_icons/kelthuzad.xml")

AddModCharacter("kelthuzad", "FEMALE")

STRINGS.CHARACTERS.KELTHUZAD = require "speech_kelthuzad"

STRINGS.NAMES.KELTHUZAD_STAFF = "黑檀之寒法杖"
STRINGS.RECIPE_DESC.KELTHUZAD_STAFF  = "冰雪将不在融化" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE.KELTHUZAD_STAFF  = "它让我直冒冷汗。。" 
STRINGS.CHARACTERS.KELTHUZAD.DESCRIBE.KELTHUZAD_STAFF = "所有人都将臣服，只是时机未到!" 

Recipe("gears", {Ingredient("marble", 5), Ingredient("goldnugget", 1)}, RECIPETABS.REFINE, TECH.NONE, nil, nil, nil, 1, "kelthuzad")

Recipe("kelthuzad_staff", {Ingredient("bluegem", 1), Ingredient("flint", 2)}, RECIPETABS.MAGIC,  TECH.NONE, 
nil, nil, nil, nil, "kelthuzad",
"images/inventoryimages/kelthuzad_staff.xml", 
"kelthuzad_staff.tex")

----------------等级显示

AddPrefabPostInit("nightmarefuel", function(inst)

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("tradable")
end)

local kelthuzad_item = {
       kelthuzad_staff = true
}

local function draw(inst)
  if inst.components.drawable then
    local oldondrawnfn = inst.components.drawable.ondrawnfn or nil
    inst.components.drawable.ondrawnfn = function(inst, image, src)

    if oldondrawnfn ~= nil then
          oldondrawnfn(inst, image, src)
    end

    if image ~= nil and kelthuzad_item[image] ~= nil then
          inst.AnimState:OverrideSymbol("SWAP_SIGN", resolvefilepath("images/inventoryimages/"..image..".xml"), image..".tex")
    end
    end
  end
end

AddPrefabPostInit("minisign", draw)
AddPrefabPostInit("minisign_drawn", draw)

