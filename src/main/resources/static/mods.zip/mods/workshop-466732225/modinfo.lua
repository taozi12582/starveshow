name = "No Thermal Stone Durability"
description = "Like seriously Klei, it was the last item you would've ever wanted to nerf.\n\nServer-side only. v.FULL 4"
author = "Tekture (PrzemoLSZ)"
version = "FULL 4"

forumthread = ""

api_version = 10

dont_starve_compatible = true
reign_of_giants_compatible = true
dst_compatible = true

all_clients_require_mod = false
clients_only_mod = false

icon_atlas = "heatrock_tweak.xml"
icon = "heatrock_tweak.tex"
